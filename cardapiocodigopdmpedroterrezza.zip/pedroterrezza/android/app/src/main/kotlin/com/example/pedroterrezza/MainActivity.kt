package com.example.pedroterrezza

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
